#ifndef HASH_INDEX_H
#define HASH_INDEX_H

#include "config.h"
#include "record.h"
#include <stdlib.h>

// entry for a hash bucket (key + list of records)
typedef struct HashIndexEntry {
  uint16_t key;
  RecordNode *record;
  struct HashIndexEntry *next;
} HashIndexEntry;

typedef struct HashIndex {
  HashIndexEntry *buckets[HASH_INDEX_SIZE];
} HashIndex;

void hash_index_print(const HashIndex *index);
void hash_index_init(HashIndex *index);
void hash_index_cleanup(HashIndex *index);
void hash_index_build(HashIndex *index, const Record *records,
                      size_t num_records);
size_t hash_index_get_records(const HashIndex *index, uint16_t key,
                              Record *recs_out);

#endif // HASH_INDEX_H
