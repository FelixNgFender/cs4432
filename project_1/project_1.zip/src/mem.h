#ifndef MEM_H
#define MEM_H

void *check_malloc(int size);

#endif // MEM_H
