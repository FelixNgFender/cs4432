#ifndef UTIL_H
#define UTIL_H

long strtol_or_exit(const char *nptr);

#endif // UTIL_H
