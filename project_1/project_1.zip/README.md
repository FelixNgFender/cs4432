# CS 4432 Project 1: Buffer Manager

Author: Thinh Nguyen - 670714455

## Get started

`make test` to run the default test.

`make run` will compile the `main` executable in the `./bin` directory and run
it with the default `TARGET_FLAGS=3` which tells the buffer manager to create a
buffer of size 3.

`make` alone compiles the executable and copies over the test data to the build
directory.

`make clean` to clean up compiled files and test copies.

## Test results

All my tests worked as expected.

## Design decisions

Nothing outside of the guidelines.
